#!/usr/bin/env bash



stats=`echo hiveos | netcat 127.0.0.1 4028`
khs=`echo hiveos  | netcat  127.0.0.1 4028 | jq  ".hs" | jq "add"`

echo stats: $stats
echo khs:   $khs

